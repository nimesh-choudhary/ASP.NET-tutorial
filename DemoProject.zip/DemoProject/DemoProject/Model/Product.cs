﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DemoProject.Model
{
    public class Product
    {
        [JsonPropertyName("img")] // to help in mapping with img to Image function i.e. mention in product.json file
        public string Image { get; set; }
        public int Id { get; set; }
        public string Maker { get; set; }
        public string Url { get; set; }
        public int[] Ratings { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        //what if you want to convert the text into json format then for that we have to user Serializable 

        public override string ToString() => JsonSerializer.Serialize<Product>(this);
    }
}
