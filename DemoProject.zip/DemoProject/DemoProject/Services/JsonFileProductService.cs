﻿using DemoProject.Model;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace DemoProject.Services
{
    public class JsonFileProductService
    {

        //IWebHostEnvironmet helps us to retrive the JSON file that we want
        public JsonFileProductService(IWebHostEnvironment webHostEnvironment)
        {
            WebHostEnvironment = webHostEnvironment;
        }


        // this WebHostEnvironment is used to get the path of the JSON file that we want to retrive
        public IWebHostEnvironment WebHostEnvironment { get; }

        private string JsonFileName => Path.Combine(WebHostEnvironment.WebRootPath, "data", "products.json");

        /* so in this Path.Combine used the three parameters 
        1. wwwroot folder's path
        2. path of folder in which JSON file is present
        3. name of JSON file that we want to retrive
        
        
        */


        // IEnumerable is an interface that defines a standard way for classes to represent a sequence of objects that can be iterated over.

        /* So it will iterate all the all the objects that present in the JSON file and add it into Product List 
         So generally JSON format represent as 
        {
            Object1{
                name:
                id:
                address:
            }
            Object2{
                name:
                id:
                address:
            }
        }

        so according the following example IEnumerable will iterate two time and add both the objects into Product List as mentioned in below code
         
         
         
         */
        public IEnumerable<Product> GetProducts()
        {

            // so here we are reading this file
            using var jsonFileReader = File.OpenText(JsonFileName);
            //Deserialize means to convert the JSON into object

            //where ReadToEnd means to read the whole file and add into the Product L
            //ist
            return JsonSerializer.Deserialize<Product[]>(jsonFileReader.ReadToEnd(),
                new JsonSerializerOptions
                {
                    // this will tells whether upper case or lower case will affect or not
                    PropertyNameCaseInsensitive = true
                });
        }
    }
}
